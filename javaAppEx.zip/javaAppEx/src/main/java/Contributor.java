public class Contributor {
    private String repositoryName;
    private String userName;
    private int contributeCount;
    private int followersCount;
    private String followersUrl;

    public String getRepositoryName() {
        return repositoryName;
    }

    public void setRepositoryName(String repositoryName) {
        this.repositoryName = repositoryName;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public int getContributeCount() {
        return contributeCount;
    }

    public void setContributeCount(int contributeCount) {
        this.contributeCount = contributeCount;
    }

    public int getFollowersCount() {
        return followersCount;
    }

    public void setFollowersCount(int followersCount) {
        this.followersCount = followersCount;
    }

    public String getFollowersUrl() {
        return followersUrl;
    }

    public void setFollowersUrl(String followersUrl) {
        this.followersUrl = followersUrl;
    }

    @Override
    public String toString() {
        return getRepositoryName() + "," + getUserName() + "," + getContributeCount() + "," + getFollowersCount();
    }
}
