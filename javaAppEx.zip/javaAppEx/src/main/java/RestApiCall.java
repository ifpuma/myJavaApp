import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.*;

public class RestApiCall {

    private static String token = "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";

    public static void main(String[] args) throws IOException {

        try {
            File file = new File(args[0] + "_repos.csv");
            if (file.exists())
                file.delete();
            file = new File(args[0] + "_users.csv");
            if (!file.exists())
                file.delete();
            Scanner input = new Scanner(System.in);
            String urlString = "https://api.github.com/orgs/" + args[0] + "/repos";
            URL newUrl = new URL(urlString);
            URLConnection connection = newUrl.openConnection();
            Map<String, String> parameters = new HashMap<>();
            parameters.put("per_page", String.valueOf(100));
            parameters.put("sort", "updated");
            parameters.put("order", "desc");
            String s = getGithubContentUsingURLConnection(token, urlString, parameters);


            List<GitHubRepository> gitHubRepositoryList = getForkedRepositories(args[0], s, Integer.parseInt(args[1]));
            listTopContributors(args[0], gitHubRepositoryList, Integer.parseInt(args[2]));

        } catch (MalformedURLException e) {
            e.printStackTrace();
        }

    }

    private static void listTopContributors(String orgName, List<GitHubRepository> gitHubRepositoryList, int contributorCount) throws IOException {

        writeToFile(orgName + "_users", "ContributedRepository,UserName,ContributeCount,FollowersCount");
        for (GitHubRepository repo : gitHubRepositoryList) {
            String s = getGithubContentUsingURLConnection(token, repo.getContributersUrl(), null);
            writeTopContributors(orgName, repo.getName(), s, contributorCount);
        }
    }

    private static void writeTopContributors(String orgName, String repositoryName, String s, int contributorCount) throws IOException {
        JSONArray jsonArray = new JSONArray(s);
        for (int i = 0; i < contributorCount; i++) {
            Contributor contributor = new Contributor();
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            contributor.setRepositoryName(repositoryName);
            contributor.setUserName(jsonObject.get("login").toString());
            contributor.setFollowersUrl(jsonObject.get("followers_url").toString());
            contributor.setContributeCount(Integer.parseInt(jsonObject.get("contributions").toString()));
            contributor.setFollowersCount(findFollowersCount(contributor.getFollowersUrl()));
            writeToFile(orgName + "_users", contributor.toString());
        }
    }

    private static int findFollowersCount(String followersUrl) throws IOException {
        int pageCount = 0;
        int perPage = 0;
        do {
            pageCount++;
            Map<String, String> parameters = new HashMap<>();
            parameters.put("per_page", String.valueOf(100));
            parameters.put("page", String.valueOf(pageCount));
            String s = getGithubContentUsingURLConnection(token, followersUrl, parameters);
            JSONArray jsonArray = new JSONArray(s);
            perPage = jsonArray.length();

        } while (perPage == 100);
        return (pageCount * 100) + perPage;
    }

    private static List<GitHubRepository> getForkedRepositories(String orgName, String jsonString, Integer numberForkedRepos) throws IOException {
        JSONArray jsonArray = new JSONArray(jsonString);
        JSONArray forksArray = getSortedRepositories(jsonArray);
        writeToFile(orgName + "_repos", "RepoName,URL,Description,Forks");
        List<GitHubRepository> repoList = new ArrayList<>();
        for (int i = 0; i < numberForkedRepos; i++) {
            JSONObject jsonObject = forksArray.getJSONObject(i);
            GitHubRepository repo = new GitHubRepository();
            repo.setName(jsonObject.get("name").toString());
            repo.setUrl(jsonObject.get("url").toString());
            repo.setForksCount(Integer.parseInt(jsonObject.get("forks").toString()));
            repo.setDescription(jsonObject.get("description").toString());
            repo.setContributersUrl(jsonObject.get("contributors_url").toString());
            repoList.add(repo);
            writeToFile(orgName + "_repos", repo.toString());
        }
        return repoList;
    }

    private static JSONArray getSortedRepositories(JSONArray jsonArr) {

        JSONArray sortedJsonArray = new JSONArray();

        List<JSONObject> jsonValues = new ArrayList<JSONObject>();
        for (int i = 0; i < jsonArr.length(); i++) {
            jsonValues.add(jsonArr.getJSONObject(i));
        }
        Collections.sort(jsonValues, new Comparator<JSONObject>() {
            private static final String KEY_NAME = "forks";

            @Override
            public int compare(JSONObject a, JSONObject b) {
                int compare = 0;

                try {
                    int valA = (Integer) a.get(KEY_NAME);
                    int valB = (Integer) b.get(KEY_NAME);
                    compare = Integer.compare(valB, valA);
                } catch (JSONException e) {
                    e.getMessage();
                }

                return compare;
            }
        });

        for (int i = 0; i < jsonArr.length(); i++) {
            sortedJsonArray.put(jsonValues.get(i));
        }

        return sortedJsonArray;
    }

    private static String getParamsString(String url, Map<String, String> params) throws UnsupportedEncodingException {
        StringBuilder result = new StringBuilder();
        result.append(url);
        result.append("?");
        for (Map.Entry<String, String> entry : params.entrySet()) {
            result.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
            result.append("=");
            result.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
            result.append("&");
        }

        String resultString = result.toString();
        return resultString.length() > 0
                ? resultString.substring(0, resultString.length() - 1)
                : resultString;
    }

    private static String getGithubContentUsingURLConnection(String token, String newUrl, Map<String, String> parameters) throws IOException {
        try {
            if (parameters != null) {
                newUrl = getParamsString(newUrl, parameters);
            }
            URL myURL = new URL(newUrl);
            URLConnection connection = myURL.openConnection();
            token = token + ":x-oauth-basic";
            String authString = "Basic " + Base64.getEncoder().encodeToString(token.getBytes());
            connection.setRequestProperty("Authorization", authString);

            InputStream crunchifyInStream = connection.getInputStream();
            //System.out.println(crunchifyGetStringFromStream(crunchifyInStream));

            return crunchifyGetStringFromStream(crunchifyInStream);


        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }

    }

    private static String crunchifyGetStringFromStream(InputStream crunchifyStream) throws IOException {
        if (crunchifyStream != null) {
            Writer crunchifyWriter = new StringWriter();

            char[] crunchifyBuffer = new char[2048];
            try {
                Reader crunchifyReader = new BufferedReader(new InputStreamReader(crunchifyStream, "UTF-8"));
                int counter;
                while ((counter = crunchifyReader.read(crunchifyBuffer)) != -1) {
                    crunchifyWriter.write(crunchifyBuffer, 0, counter);
                }
            } finally {
                crunchifyStream.close();
            }

            return crunchifyWriter.toString();


        } else {
            return "No Contents";
        }
    }

    private static void writeToFile(String fileName, String sToWrite) throws IOException {
        File file = new File(fileName + ".csv");
        if (!file.exists())
            file.createNewFile();
        BufferedWriter bw = new BufferedWriter(new FileWriter(file, true));
        bw.write(sToWrite);
        bw.newLine();
        bw.close();
    }
}