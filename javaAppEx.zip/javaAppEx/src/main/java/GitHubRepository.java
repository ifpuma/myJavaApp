public class GitHubRepository {
    private String name;
    private int forksCount;
    private String url;
    private String description;
    private String contributersUrl;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getForksCount() {
        return forksCount;
    }

    public void setForksCount(int forksCount) {
        this.forksCount = forksCount;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getContributersUrl() {
        return contributersUrl;
    }

    public void setContributersUrl(String contributersUrl) {
        this.contributersUrl = contributersUrl;
    }

    @Override
    public String toString() {
        return getName() + "," + getUrl() + "," + getDescription() + "," + getForksCount();
    }
}
